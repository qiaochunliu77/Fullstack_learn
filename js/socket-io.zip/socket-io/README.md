Connection: Upgrade 表示要升级协议
Upgrade: websocket 要升级协议到websocket协议



<!-- https://zhuanlan.zhihu.com/p/74326818 -->